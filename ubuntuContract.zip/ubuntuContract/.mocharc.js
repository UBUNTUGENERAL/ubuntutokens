module.exports = {
  require: "hardhat/register",
  timeout: 20000,
};
