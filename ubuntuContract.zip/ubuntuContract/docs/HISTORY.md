# HISTORY (How it happened)

## Early

1. SushiToken Deployed
2. MasterChef Deployed
3. SushiToken Ownership Transfered to MasterChef
4. TimeLock Deployed
5. SushiFactory Deployed
6. SushiRouter Deployed
7. Migrator Deployed

## Pre-migration

Incentivised pools for Uniswap LP tokens were added by Master Chef to encourage locking liquidity into the platform before eventual migration of those Uniswap LP tokens to SushiSwap SLP tokens.

## Migration

...

## Post-migration

...
